// ── Shared Utility / Formatter Functions ──────────────────────────────────────

/**
 * Format a number as Indian Rupees (₹).
 * Example: formatINR(3499) → "₹3,499"
 */
export function formatINR(amount) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Generate a short random booking ID.
 * Example: "BK482910"
 */
export function generateBookingId() {
  return "BK" + Date.now().toString().slice(-6);
}

/**
 * Compute the average rating from an array of review objects.
 * Returns a float rounded to one decimal place, or a fallback.
 */
export function avgRating(reviewsArray, fallback = 0) {
  if (!reviewsArray || reviewsArray.length === 0) return fallback;
  const sum = reviewsArray.reduce((acc, r) => acc + r.rating, 0);
  return parseFloat((sum / reviewsArray.length).toFixed(1));
}

/**
 * Return today's date string in YYYY-MM-DD format (for date input min values).
 */
export function todayISO() {
  return new Date().toISOString().split("T")[0];
}

/**
 * Return a localised date string in Indian format.
 * Example: "15 Jun 2025"
 */
export function toIndianDate(isoString) {
  if (!isoString) return "";
  return new Date(isoString).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}
