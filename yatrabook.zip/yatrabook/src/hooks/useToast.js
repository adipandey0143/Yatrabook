import { useState, useCallback } from "react";

/**
 * useToast – lightweight toast notification hook.
 *
 * Usage:
 *   const { toast, showToast } = useToast();
 *   showToast("Booking confirmed! 🎉");
 *   showToast("Something went wrong", "error");
 *
 *   // In JSX:
 *   <Toast toast={toast} />
 */
export function useToast(duration = 3000) {
  const [toast, setToast] = useState(null);

  const showToast = useCallback(
    (msg, type = "success") => {
      setToast({ msg, type });
      setTimeout(() => setToast(null), duration);
    },
    [duration]
  );

  return { toast, showToast };
}
