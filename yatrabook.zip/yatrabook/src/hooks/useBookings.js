import { useState } from "react";
import { generateBookingId } from "../utils/formatters";

/**
 * useBookings – manages the in-memory bookings list.
 *
 * In a real app this would hit a backend API (Node/Express + MongoDB).
 * For now all state lives in React memory.
 */
export function useBookings() {
  const [bookings, setBookings] = useState([]);

  /** Confirm a new booking and add it to the list. */
  function confirmBooking(item, type, date) {
    const booking = {
      id: generateBookingId(),
      item,
      type,
      date: date || "TBD",
      status: "Confirmed",
      amount: item.price,
      bookedOn: new Date().toLocaleDateString("en-IN"),
    };
    setBookings((prev) => [booking, ...prev]);
    return booking;
  }

  /** Cancel an existing booking by its id. */
  function cancelBooking(id) {
    setBookings((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status: "Cancelled" } : b))
    );
  }

  return { bookings, confirmBooking, cancelBooking };
}
