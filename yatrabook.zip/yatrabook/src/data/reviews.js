// ── Reviews Database ──────────────────────────────────────────────────────────
// itemId links a review to a flight / hotel / package by their id field.

const REVIEWS = [
  {
    id: "RV001",
    user: "Priya Sharma",
    avatar: "🙋‍♀️",
    rating: 5,
    text: "The Varanasi package was absolutely divine! Ganga Aarti was life-changing. Highly recommend!",
    itemId: "PK001",
    date: "15 Apr 2025",
  },
  {
    id: "RV002",
    user: "Rahul Verma",
    avatar: "👨",
    rating: 5,
    text: "Kerala houseboat experience exceeded all expectations. Food was amazing, service impeccable.",
    itemId: "PK002",
    date: "22 Mar 2025",
  },
  {
    id: "RV003",
    user: "Anita Gupta",
    avatar: "👩",
    rating: 4,
    text: "Taj Ganges is stunning. The Ganga view from the room is worth every rupee spent.",
    itemId: "HT001",
    date: "8 May 2025",
  },
  {
    id: "RV004",
    user: "Suresh Patel",
    avatar: "🧔",
    rating: 5,
    text: "Kashmir was magical. Snow-capped mountains, Dal Lake shikara — pure heaven!",
    itemId: "PK003",
    date: "2 Jun 2025",
  },
];

export default REVIEWS;
