// ── Destinations Reference ────────────────────────────────────────────────────

export const DESTINATION_CITIES = [
  "Varanasi",
  "Lucknow",
  "Kerala",
  "Jammu & Kashmir",
  "Bangalore",
  "Azamgarh",
  "Mumbai",
  "Delhi",
];

export const FEATURED_DESTINATIONS = [
  { name: "Varanasi",         icon: "🪔", tag: "Spiritual"  },
  { name: "Kerala",           icon: "🌴", tag: "Nature"     },
  { name: "Jammu & Kashmir",  icon: "❄️", tag: "Adventure"  },
  { name: "Lucknow",          icon: "🕌", tag: "Heritage"   },
  { name: "Bangalore",        icon: "🌸", tag: "City"       },
  { name: "Azamgarh",         icon: "🎨", tag: "Culture"    },
];
