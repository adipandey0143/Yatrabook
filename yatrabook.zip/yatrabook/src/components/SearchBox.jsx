import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { DESTINATION_CITIES } from "../data/destinations";

const inputStyle = {
  background: "var(--card)",
  border: "1px solid var(--border)",
  color: "var(--text)",
  borderRadius: 10,
  padding: "12px 16px",
  fontSize: 14,
  fontFamily: "var(--font)",
  outline: "none",
  width: "100%",
};

const labelStyle = {
  fontSize: 11,
  color: "var(--muted)",
  marginBottom: 6,
  letterSpacing: 1,
  display: "block",
};

/**
 * SearchBox – flight / hotel / package search form.
 * On submit it navigates to /search with query state.
 */
export default function SearchBox() {
  const navigate = useNavigate();
  const [type, setType]         = useState("flights");
  const [from, setFrom]         = useState("");
  const [to, setTo]             = useState("");
  const [date, setDate]         = useState("");

  function handleSearch() {
    navigate("/search", { state: { type, from, to, date } });
  }

  const tabBtn = (t, label) => ({
    background:
      type === t
        ? "linear-gradient(135deg, var(--accent), #FF8C5A)"
        : "var(--card)",
    color: "#fff",
    border: "none",
    borderRadius: 10,
    padding: "8px 20px",
    fontSize: 13,
    cursor: "pointer",
    fontFamily: "var(--font)",
    fontWeight: 700,
    transition: "all 0.2s",
  });

  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: 20,
        padding: 24,
      }}
    >
      {/* Type selector */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {[["flights", "✈ Flights"], ["hotels", "🏨 Hotels"], ["packages", "🗺 Packages"]].map(
          ([t, l]) => (
            <button key={t} style={tabBtn(t)} onClick={() => setType(t)}>
              {l}
            </button>
          )
        )}
      </div>

      {/* Fields */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            type === "flights" ? "1fr 1fr 1fr auto" : "1fr 1fr auto",
          gap: 12,
        }}
      >
        {type === "flights" && (
          <div>
            <label style={labelStyle}>FROM</label>
            <select style={inputStyle} value={from} onChange={(e) => setFrom(e.target.value)}>
              <option value="">Any City</option>
              {DESTINATION_CITIES.map((d) => <option key={d}>{d}</option>)}
            </select>
          </div>
        )}

        <div>
          <label style={labelStyle}>{type === "flights" ? "TO" : "DESTINATION"}</label>
          <select style={inputStyle} value={to} onChange={(e) => setTo(e.target.value)}>
            <option value="">Any Destination</option>
            {DESTINATION_CITIES.map((d) => <option key={d}>{d}</option>)}
          </select>
        </div>

        <div>
          <label style={labelStyle}>DATE</label>
          <input
            type="date"
            style={inputStyle}
            value={date}
            onChange={(e) => setDate(e.target.value)}
            min="2025-06-01"
          />
        </div>

        <button
          style={{
            background: "linear-gradient(135deg, var(--accent), #FF8C5A)",
            color: "#fff",
            border: "none",
            borderRadius: 10,
            padding: "12px 28px",
            fontWeight: 700,
            fontSize: 15,
            cursor: "pointer",
            fontFamily: "var(--font)",
            alignSelf: "flex-end",
            whiteSpace: "nowrap",
          }}
          onClick={handleSearch}
        >
          Search →
        </button>
      </div>
    </div>
  );
}
