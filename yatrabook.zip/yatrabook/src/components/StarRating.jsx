import React from "react";

/**
 * StarRating – renders 1–5 filled/empty stars.
 *
 * Props:
 *   rating  – number (e.g. 4.7)
 *   size    – font size in px (default 14)
 */
export default function StarRating({ rating, size = 14 }) {
  return (
    <span style={{ fontSize: size }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <span
          key={i}
          style={{ color: i <= Math.round(rating) ? "#F59E0B" : "var(--border)" }}
        >
          ★
        </span>
      ))}
    </span>
  );
}
