import React, { useState } from "react";
import StarRating from "./StarRating";
import { avgRating } from "../utils/formatters";

/**
 * ReviewSection – displays reviews for an item and allows logged-in users
 * to submit a new review.
 *
 * Props:
 *   itemId      – the id of the item being reviewed
 *   reviews     – full reviews array (filtered inside)
 *   onSubmit    – fn(itemId, { rating, text })
 *   user        – current user object or null
 */
export default function ReviewSection({ itemId, reviews, onSubmit, user }) {
  const [rating, setRating]   = useState(5);
  const [text, setText]       = useState("");

  const itemReviews = reviews.filter((r) => r.itemId === itemId);
  const avg = avgRating(itemReviews, 0);

  function handleSubmit() {
    if (!text.trim()) return;
    onSubmit(itemId, { rating, text });
    setText("");
    setRating(5);
  }

  const card = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
  };

  return (
    <div style={card}>
      {/* Header */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 20,
        }}
      >
        <h3 style={{ margin: 0 }}>Reviews ({itemReviews.length})</h3>
        {itemReviews.length > 0 && (
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 28, fontWeight: 800, color: "var(--accent)" }}>{avg}</span>
            <StarRating rating={avg} size={18} />
          </div>
        )}
      </div>

      {/* Write a review */}
      {user ? (
        <div
          style={{
            background: "var(--surface)",
            borderRadius: 12,
            padding: 16,
            marginBottom: 20,
          }}
        >
          <div style={{ fontSize: 13, color: "var(--muted)", marginBottom: 8 }}>Your Rating</div>
          <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
            {[1, 2, 3, 4, 5].map((s) => (
              <button
                key={s}
                onClick={() => setRating(s)}
                style={{
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  fontSize: 24,
                  color: s <= rating ? "#F59E0B" : "var(--border)",
                  padding: 0,
                }}
              >
                ★
              </button>
            ))}
          </div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Share your experience…"
            style={{
              background: "var(--card)",
              border: "1px solid var(--border)",
              color: "var(--text)",
              borderRadius: 10,
              padding: "12px 16px",
              fontSize: 14,
              fontFamily: "var(--font)",
              outline: "none",
              width: "100%",
              resize: "none",
              height: 80,
              marginBottom: 10,
            }}
          />
          <button
            onClick={handleSubmit}
            style={{
              background: "linear-gradient(135deg, var(--accent), #FF8C5A)",
              color: "#fff",
              border: "none",
              borderRadius: 10,
              padding: "8px 20px",
              fontWeight: 700,
              fontSize: 13,
              cursor: "pointer",
              fontFamily: "var(--font)",
            }}
          >
            Submit Review
          </button>
        </div>
      ) : (
        <div style={{ color: "var(--muted)", fontSize: 14, marginBottom: 16 }}>
          Please log in to leave a review.
        </div>
      )}

      {/* Review list */}
      {itemReviews.map((rv) => (
        <div
          key={rv.id}
          style={{ borderTop: "1px solid var(--border)", paddingTop: 16, marginTop: 16 }}
        >
          <div style={{ display: "flex", gap: 10, marginBottom: 8 }}>
            <span style={{ fontSize: 28 }}>{rv.avatar}</span>
            <div>
              <div style={{ fontWeight: 700 }}>{rv.user}</div>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <StarRating rating={rv.rating} size={12} />
                <span style={{ fontSize: 11, color: "var(--muted)" }}>{rv.date}</span>
              </div>
            </div>
          </div>
          <p style={{ color: "var(--muted)", fontSize: 14, margin: 0, lineHeight: 1.6, fontStyle: "italic" }}>
            "{rv.text}"
          </p>
        </div>
      ))}

      {itemReviews.length === 0 && (
        <div style={{ color: "var(--muted)", fontSize: 14 }}>No reviews yet. Be the first! 🙏</div>
      )}
    </div>
  );
}
