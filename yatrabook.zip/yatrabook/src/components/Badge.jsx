import React from "react";

/**
 * Badge – small pill label with customisable colour.
 *
 * Props:
 *   children – label text
 *   color    – hex colour string (default amber/gold)
 */
export default function Badge({ children, color = "#F59E0B" }) {
  return (
    <span
      style={{
        background: color + "22",
        color,
        border: `1px solid ${color}44`,
        borderRadius: 20,
        padding: "2px 10px",
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: 0.5,
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </span>
  );
}
