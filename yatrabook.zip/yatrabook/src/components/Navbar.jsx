import React from "react";
import { useNavigate, useLocation } from "react-router-dom";

/**
 * Navbar – top navigation bar.
 * Receives the current user and a logout handler as props.
 */
export default function Navbar({ user, onLogout }) {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const isAdmin = user?.isAdmin;

  const linkStyle = (path) => ({
    background: "none",
    border: "none",
    color: pathname === path ? "var(--accent)" : "var(--muted)",
    cursor: "pointer",
    padding: "8px 14px",
    borderRadius: 8,
    fontSize: 14,
    fontFamily: "var(--font)",
    fontWeight: pathname === path ? 700 : 400,
    transition: "color 0.2s",
  });

  return (
    <nav
      style={{
        background: "var(--surface)",
        borderBottom: "1px solid var(--border)",
        padding: "0 24px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        height: 64,
        position: "sticky",
        top: 0,
        zIndex: 100,
      }}
    >
      {/* Logo */}
      <div
        onClick={() => navigate("/")}
        style={{
          fontSize: 26,
          fontWeight: 800,
          background: "linear-gradient(135deg, var(--accent), var(--accent2))",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          cursor: "pointer",
          letterSpacing: -1,
        }}
      >
        ✈ YatraBook
      </div>

      {/* Nav Links */}
      <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
        <button style={linkStyle("/")} onClick={() => navigate("/")}>Home</button>
        <button style={linkStyle("/search")} onClick={() => navigate("/search")}>Explore</button>
        <button style={linkStyle("/packages")} onClick={() => navigate("/packages")}>Packages</button>

        {user && (
          <button style={linkStyle("/dashboard")} onClick={() => navigate("/dashboard")}>
            My Bookings
          </button>
        )}

        {isAdmin && (
          <button
            style={{ ...linkStyle("/admin"), color: "var(--accent2)" }}
            onClick={() => navigate("/admin")}
          >
            Admin ⚙️
          </button>
        )}

        {user ? (
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginLeft: 8 }}>
            <span style={{ fontSize: 13, color: "var(--muted)" }}>🙏 {user.name}</span>
            <button
              style={{
                background: "transparent",
                color: "var(--accent)",
                border: "1.5px solid var(--accent)",
                borderRadius: 10,
                padding: "8px 16px",
                fontSize: 13,
                cursor: "pointer",
                fontFamily: "var(--font)",
              }}
              onClick={onLogout}
            >
              Logout
            </button>
          </div>
        ) : (
          <button
            style={{
              background: "linear-gradient(135deg, var(--accent), #FF8C5A)",
              color: "#fff",
              border: "none",
              borderRadius: 10,
              padding: "9px 20px",
              fontSize: 13,
              cursor: "pointer",
              fontFamily: "var(--font)",
              fontWeight: 700,
              marginLeft: 8,
            }}
            onClick={() => navigate("/login")}
          >
            Login
          </button>
        )}
      </div>
    </nav>
  );
}
