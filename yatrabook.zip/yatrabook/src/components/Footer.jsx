import React from "react";

const COLUMNS = [
  {
    title: "Destinations",
    links: ["Varanasi", "Kerala", "Jammu & Kashmir", "Lucknow", "Bangalore"],
  },
  {
    title: "Services",
    links: ["Flight Booking", "Hotel Booking", "Tour Packages", "Travel Insurance"],
  },
  {
    title: "Support",
    links: ["Help Center", "Cancellation Policy", "Contact Us", "About Us"],
  },
];

export default function Footer() {
  return (
    <footer
      style={{
        background: "var(--surface)",
        borderTop: "1px solid var(--border)",
        padding: "48px 20px 24px",
        marginTop: 60,
      }}
    >
      <div
        style={{
          maxWidth: 1100,
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
          gap: 32,
        }}
      >
        {/* Brand blurb */}
        <div>
          <div
            style={{
              fontSize: 22,
              fontWeight: 800,
              background: "linear-gradient(135deg, var(--accent), var(--accent2))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              marginBottom: 12,
            }}
          >
            ✈ YatraBook
          </div>
          <p style={{ color: "var(--muted)", fontSize: 13, lineHeight: 1.7 }}>
            Your trusted travel partner for incredible journeys across India.
            Book flights, hotels & holiday packages.
          </p>
        </div>

        {COLUMNS.map((col) => (
          <div key={col.title}>
            <div
              style={{
                fontWeight: 700,
                marginBottom: 12,
                color: "var(--accent)",
                fontSize: 13,
                letterSpacing: 0.5,
              }}
            >
              {col.title}
            </div>
            {col.links.map((l) => (
              <div
                key={l}
                style={{
                  color: "var(--muted)",
                  fontSize: 13,
                  marginBottom: 8,
                  cursor: "pointer",
                  transition: "color 0.2s",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.color = "var(--text)")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "var(--muted)")}
              >
                {l}
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Bottom bar */}
      <div
        style={{
          maxWidth: 1100,
          margin: "32px auto 0",
          borderTop: "1px solid var(--border)",
          paddingTop: 20,
          display: "flex",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: 12,
        }}
      >
        <span style={{ color: "var(--muted)", fontSize: 12 }}>
          © 2025 YatraBook. All rights reserved. 🇮🇳 Made with ❤️ for India
        </span>
        <span style={{ color: "var(--muted)", fontSize: 12 }}>
          Payments in ₹ INR &nbsp;•&nbsp; GST Registered &nbsp;•&nbsp; IATA Certified
        </span>
      </div>
    </footer>
  );
}
