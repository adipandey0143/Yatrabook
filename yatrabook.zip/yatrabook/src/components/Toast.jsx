import React from "react";

/**
 * Toast – floating notification component.
 *
 * Props:
 *   toast  – { msg: string, type: "success" | "error" } | null
 */
export default function Toast({ toast }) {
  if (!toast) return null;

  return (
    <div
      style={{
        position: "fixed",
        bottom: 30,
        right: 30,
        background: toast.type === "error" ? "var(--red)" : "var(--green)",
        color: "#fff",
        padding: "14px 24px",
        borderRadius: 12,
        zIndex: 999,
        fontWeight: 600,
        fontSize: 15,
        boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
        animation: "slideInRight 0.3s ease",
      }}
    >
      {toast.msg}
    </div>
  );
}
