import React, { useState } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";

// Layout
import Navbar   from "./components/Navbar";
import Footer   from "./components/Footer";
import Toast    from "./components/Toast";

// Pages
import HomePage     from "./pages/HomePage";
import SearchPage   from "./pages/SearchPage";
import DetailPage   from "./pages/DetailPage";
import PackagesPage from "./pages/PackagesPage";
import BookingPage  from "./pages/BookingPage";
import DashboardPage from "./pages/DashboardPage";
import LoginPage    from "./pages/LoginPage";
import AdminPage    from "./pages/AdminPage";

// Data & hooks
import INITIAL_REVIEWS from "./data/reviews";
import { useToast }    from "./hooks/useToast";
import { useBookings } from "./hooks/useBookings";

export default function App() {
  const navigate = useNavigate();

  // ── Global State ────────────────────────────────────────────────────────────
  const [user, setUser]       = useState(null);
  const [cart, setCart]       = useState(null);            // { item, type, date }
  const [reviews, setReviews] = useState(INITIAL_REVIEWS);

  const { toast, showToast }               = useToast();
  const { bookings, confirmBooking, cancelBooking } = useBookings();

  // ── Auth helpers ─────────────────────────────────────────────────────────────
  function handleLogin(userData) {
    setUser(userData);
  }

  function handleLogout() {
    setUser(null);
    navigate("/");
  }

  // ── Booking flow ─────────────────────────────────────────────────────────────
  function handleBook(item, type) {
    if (!user) {
      navigate("/login");
      return;
    }
    setCart({ item, type, date: "" });
    navigate("/booking");
  }

  function handleConfirmBooking(item, type, date) {
    const bk = confirmBooking(item, type, date);
    showToast("Booking confirmed! 🎉");
    return bk;
  }

  // ── Reviews ───────────────────────────────────────────────────────────────────
  function handleReviewSubmit(itemId, { rating, text }) {
    if (!user) { showToast("Please login to leave a review", "error"); return; }
    if (!text.trim()) { showToast("Please write a review", "error"); return; }

    const newReview = {
      id:     "RV" + Date.now(),
      user:   user.name,
      avatar: "😊",
      rating,
      text,
      itemId,
      date:   new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }),
    };
    setReviews((prev) => [newReview, ...prev]);
    showToast("Review submitted! 🙏");
  }

  function handleDeleteReview(id) {
    setReviews((prev) => prev.filter((r) => r.id !== id));
  }

  // ── Route guard for admin ─────────────────────────────────────────────────────
  const isAdmin = user?.isAdmin;

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)", color: "var(--text)", fontFamily: "var(--font)" }}>
      <Navbar user={user} onLogout={handleLogout} />
      <Toast toast={toast} />

      <main>
        <Routes>
          <Route path="/"          element={<HomePage />} />
          <Route path="/search"    element={<SearchPage onBook={handleBook} />} />
          <Route path="/packages"  element={<PackagesPage onBook={handleBook} />} />
          <Route
            path="/detail/:type/:id"
            element={
              <DetailPage
                user={user}
                reviews={reviews}
                onReviewSubmit={handleReviewSubmit}
                onBook={handleBook}
              />
            }
          />
          <Route
            path="/booking"
            element={
              <BookingPage
                cart={cart}
                user={user}
                onConfirm={handleConfirmBooking}
              />
            }
          />
          <Route
            path="/dashboard"
            element={
              user ? (
                <DashboardPage
                  user={user}
                  bookings={bookings}
                  onCancel={cancelBooking}
                  showToast={showToast}
                />
              ) : (
                <LoginPage onLogin={handleLogin} showToast={showToast} />
              )
            }
          />
          <Route
            path="/login"
            element={<LoginPage onLogin={handleLogin} showToast={showToast} />}
          />
          <Route
            path="/admin"
            element={
              isAdmin ? (
                <AdminPage
                  bookings={bookings}
                  reviews={reviews}
                  onDeleteReview={handleDeleteReview}
                  showToast={showToast}
                />
              ) : (
                <LoginPage onLogin={handleLogin} showToast={showToast} />
              )
            }
          />
        </Routes>
      </main>

      <Footer />
    </div>
  );
}
