import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Badge from "../components/Badge";
import { formatINR } from "../utils/formatters";
import { DESTINATION_CITIES } from "../data/destinations";

/**
 * DashboardPage – logged-in user's booking history and profile settings.
 *
 * Props:
 *   user         – current user object
 *   bookings     – array of booking objects
 *   onCancel     – fn(id) to cancel a booking
 *   showToast    – fn(msg, type)
 */
export default function DashboardPage({ user, bookings, onCancel, showToast }) {
  const navigate = useNavigate();
  const [tab, setTab] = useState("bookings");

  const card = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
  };

  const input = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    color: "var(--text)",
    borderRadius: 10,
    padding: "12px 16px",
    fontSize: 14,
    fontFamily: "var(--font)",
    outline: "none",
    width: "100%",
  };

  return (
    <div style={{ padding: "32px 20px" }}>
      <div style={{ maxWidth: 900, margin: "0 auto" }}>
        {/* Profile header */}
        <div style={{ display: "flex", gap: 16, alignItems: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 48 }}>👤</div>
          <div>
            <h2 style={{ margin: 0, fontSize: 28, fontWeight: 800 }}>{user.name}</h2>
            <div style={{ color: "var(--muted)" }}>{user.email}</div>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 8, marginBottom: 24, borderBottom: "1px solid var(--border)", paddingBottom: 12 }}>
          {["bookings", "profile"].map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              style={{
                background: "none",
                border: "none",
                color: tab === t ? "var(--accent)" : "var(--muted)",
                cursor: "pointer",
                padding: "8px 16px",
                borderBottom: tab === t ? "2px solid var(--accent)" : "2px solid transparent",
                fontFamily: "var(--font)",
                fontWeight: tab === t ? 700 : 400,
                fontSize: 15,
                textTransform: "capitalize",
              }}
            >
              {t}
            </button>
          ))}
        </div>

        {/* ── Bookings tab ── */}
        {tab === "bookings" && (
          <div>
            {bookings.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 0" }}>
                <div style={{ fontSize: 64, marginBottom: 16 }}>🧳</div>
                <h3 style={{ color: "var(--muted)", fontWeight: 400 }}>No bookings yet</h3>
                <button
                  style={{ background: "linear-gradient(135deg, var(--accent), #FF8C5A)", color: "#fff", border: "none", borderRadius: 10, padding: "12px 28px", fontWeight: 700, fontSize: 15, cursor: "pointer", fontFamily: "var(--font)", marginTop: 16 }}
                  onClick={() => navigate("/")}
                >
                  Explore Destinations
                </button>
              </div>
            ) : (
              bookings.map((bk) => (
                <div
                  key={bk.id}
                  style={{ ...card, display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}
                >
                  <div>
                    <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 8 }}>
                      <Badge color={bk.status === "Confirmed" ? "var(--green)" : bk.status === "Cancelled" ? "var(--red)" : "var(--accent2)"}>
                        {bk.status}
                      </Badge>
                      <span style={{ color: "var(--muted)", fontSize: 12 }}>#{bk.id}</span>
                    </div>
                    <h3 style={{ margin: "0 0 6px", fontSize: 17 }}>
                      {bk.item.name || `${bk.item.airline}: ${bk.item.from} → ${bk.item.to}`}
                    </h3>
                    <div style={{ color: "var(--muted)", fontSize: 13, lineHeight: 1.8 }}>
                      <div>📅 Travel: {bk.date} &nbsp;•&nbsp; Booked: {bk.bookedOn}</div>
                      <div>💰 Paid: <strong style={{ color: "var(--accent)" }}>{formatINR(bk.amount)}</strong></div>
                    </div>
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    <button
                      style={{ background: "transparent", color: "var(--accent)", border: "1.5px solid var(--accent)", borderRadius: 10, padding: "8px 14px", fontSize: 12, cursor: "pointer", fontFamily: "var(--font)" }}
                      onClick={() => showToast("Ticket download coming soon 📄")}
                    >
                      📄 Download Ticket
                    </button>

                    {bk.status === "Confirmed" && (
                      <button
                        style={{ background: "var(--red)22", color: "var(--red)", border: "1px solid var(--red)44", borderRadius: 10, padding: "8px 14px", fontSize: 12, cursor: "pointer", fontFamily: "var(--font)" }}
                        onClick={() => { onCancel(bk.id); showToast("Booking cancelled"); }}
                      >
                        Cancel Booking
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* ── Profile tab ── */}
        {tab === "profile" && (
          <div style={{ maxWidth: 500 }}>
            <div style={{ ...card, display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>FULL NAME</label>
                <input style={input} defaultValue={user.name} />
              </div>
              <div>
                <label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>EMAIL</label>
                <input style={input} defaultValue={user.email} />
              </div>
              <div>
                <label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>PHONE</label>
                <input style={input} placeholder="+91 XXXXX XXXXX" />
              </div>
              <div>
                <label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>CITY</label>
                <select style={input}>
                  <option value="">Select City</option>
                  {DESTINATION_CITIES.map((d) => <option key={d}>{d}</option>)}
                </select>
              </div>
              <button
                style={{ background: "linear-gradient(135deg, var(--accent), #FF8C5A)", color: "#fff", border: "none", borderRadius: 10, padding: "12px", fontWeight: 700, fontSize: 15, cursor: "pointer", fontFamily: "var(--font)" }}
                onClick={() => showToast("Profile saved! 🙏")}
              >
                Save Changes
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
