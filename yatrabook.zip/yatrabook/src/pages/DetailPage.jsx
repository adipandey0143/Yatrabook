import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import StarRating from "../components/StarRating";
import Badge from "../components/Badge";
import ReviewSection from "../components/ReviewSection";
import FLIGHTS from "../data/flights";
import HOTELS from "../data/hotels";
import PACKAGES from "../data/packages";
import { formatINR, avgRating } from "../utils/formatters";

/**
 * DetailPage – shows full details of a flight, hotel, or package.
 * URL pattern: /detail/:type/:id
 */
export default function DetailPage({ user, reviews, onReviewSubmit, onBook }) {
  const { type, id } = useParams();
  const navigate = useNavigate();

  // Resolve item from the right dataset
  const DB = type === "flights" ? FLIGHTS : type === "hotels" ? HOTELS : PACKAGES;
  const item = DB.find((x) => x.id === id);

  if (!item) {
    return (
      <div style={{ padding: 60, textAlign: "center", color: "var(--muted)" }}>
        <div style={{ fontSize: 64 }}>😕</div>
        <h3>Item not found</h3>
        <button onClick={() => navigate(-1)} style={{ color: "var(--accent)", background: "none", border: "none", cursor: "pointer", fontSize: 16 }}>← Go Back</button>
      </div>
    );
  }

  const itemReviews = reviews.filter((r) => r.itemId === item.id);
  const avg = avgRating(itemReviews, item.rating || 0);

  const card = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
  };

  return (
    <div style={{ padding: "32px 20px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <button
          onClick={() => navigate(-1)}
          style={{
            background: "none",
            border: "1px solid var(--border)",
            color: "var(--muted)",
            borderRadius: 8,
            padding: "8px 16px",
            cursor: "pointer",
            fontFamily: "var(--font)",
            marginBottom: 20,
          }}
        >
          ← Back
        </button>

        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 24, alignItems: "start" }}>
          {/* ── Left column ── */}
          <div>
            <div style={{ fontSize: 64, marginBottom: 16 }}>{item.img || "✈"}</div>

            <h1 style={{ fontSize: 32, fontWeight: 800, marginBottom: 8 }}>
              {item.name || `${item.from} → ${item.to}`}
            </h1>

            {item.city  && <div style={{ color: "var(--muted)", marginBottom: 16 }}>📍 {item.city}</div>}
            {item.dest  && <div style={{ color: "var(--muted)", marginBottom: 16 }}>📍 {item.dest} &nbsp;•&nbsp; {item.days} Days / {item.nights} Nights</div>}
            {item.depart && (
              <div style={{ color: "var(--muted)", marginBottom: 16 }}>
                ✈ {item.airline} &nbsp;|&nbsp; {item.depart} → {item.arrive} ({item.duration})
              </div>
            )}

            {item.desc && <p style={{ color: "var(--muted)", fontSize: 16, lineHeight: 1.7, marginBottom: 24 }}>{item.desc}</p>}
            {item.highlight && <p style={{ color: "var(--muted)", fontSize: 16, lineHeight: 1.7, marginBottom: 24, fontStyle: "italic" }}>"{item.highlight}"</p>}

            {/* Amenities */}
            {item.amenities && (
              <div style={card}>
                <h3 style={{ margin: "0 0 12px" }}>Amenities</h3>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {item.amenities.map((a) => <Badge key={a} color="var(--accent3)">{a}</Badge>)}
                </div>
              </div>
            )}

            {/* Includes */}
            {item.includes && (
              <div style={card}>
                <h3 style={{ margin: "0 0 12px" }}>What's Included</h3>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {item.includes.map((inc) => <Badge key={inc} color="var(--green)">✓ {inc}</Badge>)}
                </div>
              </div>
            )}

            {/* Reviews */}
            <ReviewSection
              itemId={item.id}
              reviews={reviews}
              onSubmit={onReviewSubmit}
              user={user}
            />
          </div>

          {/* ── Booking card (sticky) ── */}
          <div style={{ ...card, position: "sticky", top: 80 }}>
            <div style={{ fontSize: 32, fontWeight: 800, color: "var(--accent)", marginBottom: 4 }}>
              {formatINR(item.price)}
            </div>
            <div style={{ fontSize: 13, color: "var(--muted)", marginBottom: 16 }}>
              {type === "hotels" ? "per night" : "per person"}
            </div>

            <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 20 }}>
              <StarRating rating={avg} />
              <span style={{ color: "var(--muted)", fontSize: 13 }}>
                {avg} ({item.reviews || itemReviews.length} reviews)
              </span>
            </div>

            {item.seats && (
              <div
                style={{
                  fontSize: 13,
                  color: item.seats < 15 ? "var(--red)" : "var(--green)",
                  marginBottom: 16,
                }}
              >
                {item.seats < 15 ? "🔴" : "🟢"} {item.seats} seats remaining
              </div>
            )}

            <button
              onClick={() => onBook(item, type)}
              style={{
                background: "linear-gradient(135deg, var(--accent), #FF8C5A)",
                color: "#fff",
                border: "none",
                borderRadius: 10,
                padding: "14px",
                width: "100%",
                fontWeight: 700,
                fontSize: 16,
                cursor: "pointer",
                fontFamily: "var(--font)",
              }}
            >
              Book Now →
            </button>

            <div style={{ textAlign: "center", color: "var(--muted)", fontSize: 12, marginTop: 12 }}>
              🔒 Secure Payment &nbsp;•&nbsp; Free Cancellation
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
