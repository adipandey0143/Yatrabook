import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import StarRating from "../components/StarRating";
import Badge from "../components/Badge";
import FLIGHTS from "../data/flights";
import HOTELS from "../data/hotels";
import PACKAGES from "../data/packages";
import { formatINR } from "../utils/formatters";

export default function SearchPage({ onBook }) {
  const navigate = useNavigate();
  const { state } = useLocation();

  const [type, setType]       = useState(state?.type || "flights");
  const [results, setResults] = useState([]);

  useEffect(() => {
    const from = state?.from || "";
    const to   = state?.to   || "";

    if (type === "flights") {
      setResults(
        FLIGHTS.filter(
          (f) =>
            (!from || f.from.toLowerCase().includes(from.toLowerCase())) &&
            (!to   || f.to.toLowerCase().includes(to.toLowerCase()))
        )
      );
    } else if (type === "hotels") {
      setResults(
        HOTELS.filter(
          (h) => !to || h.city.toLowerCase().includes(to.toLowerCase())
        )
      );
    } else {
      setResults(
        PACKAGES.filter(
          (p) => !to || p.dest.toLowerCase().includes(to.toLowerCase())
        )
      );
    }
  }, [type, state]);

  const card = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
    transition: "border 0.2s",
  };

  const btn = {
    background: "linear-gradient(135deg, var(--accent), #FF8C5A)",
    color: "#fff",
    border: "none",
    borderRadius: 10,
    padding: "8px 20px",
    fontWeight: 700,
    fontSize: 13,
    cursor: "pointer",
    fontFamily: "var(--font)",
    marginTop: 8,
  };

  return (
    <div style={{ padding: "32px 20px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        {/* Header */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 24,
            flexWrap: "wrap",
            gap: 12,
          }}
        >
          <div>
            <h2 style={{ margin: 0, fontSize: 28, fontWeight: 800 }}>
              {type === "flights" ? "✈ Available Flights" : type === "hotels" ? "🏨 Hotels" : "🗺 Packages"}
            </h2>
            <div style={{ color: "var(--muted)", fontSize: 14, marginTop: 4 }}>
              {results.length} results found
            </div>
          </div>

          {/* Type toggle */}
          <div style={{ display: "flex", gap: 8 }}>
            {[["flights","✈"],["hotels","🏨"],["packages","🗺"]].map(([t, icon]) => (
              <button
                key={t}
                onClick={() => setType(t)}
                style={{
                  background: type === t ? "var(--accent)22" : "none",
                  color: type === t ? "var(--accent)" : "var(--muted)",
                  border: `1px solid ${type === t ? "var(--accent)" : "var(--border)"}`,
                  borderRadius: 8,
                  padding: "8px 14px",
                  cursor: "pointer",
                  fontFamily: "var(--font)",
                  fontSize: 13,
                  textTransform: "capitalize",
                }}
              >
                {icon} {t}
              </button>
            ))}
          </div>
        </div>

        {/* ── Flights ── */}
        {type === "flights" && results.map((fl) => (
          <div
            key={fl.id}
            style={{ ...card, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16, cursor: "pointer" }}
            onClick={() => navigate(`/detail/flights/${fl.id}`)}
            onMouseEnter={(e) => (e.currentTarget.style.borderColor = "var(--accent)")}
            onMouseLeave={(e) => (e.currentTarget.style.borderColor = "var(--border)")}
          >
            <div style={{ display: "flex", gap: 20, alignItems: "center", flex: 1 }}>
              <div style={{ textAlign: "center", minWidth: 80 }}>
                <div style={{ fontSize: 22 }}>✈</div>
                <div style={{ fontWeight: 700, fontSize: 13 }}>{fl.airline}</div>
                <Badge color={fl.class === "Business" ? "var(--accent2)" : "var(--accent3)"}>{fl.class}</Badge>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
                  <div>
                    <div style={{ fontSize: 24, fontWeight: 800 }}>{fl.depart}</div>
                    <div style={{ color: "var(--muted)", fontSize: 13 }}>{fl.from}</div>
                  </div>
                  <div style={{ flex: 1, textAlign: "center" }}>
                    <div style={{ fontSize: 11, color: "var(--muted)" }}>{fl.duration}</div>
                    <div style={{ height: 1, background: "var(--border)", margin: "4px 0" }} />
                    <div style={{ fontSize: 11, color: "var(--muted)" }}>Direct</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 24, fontWeight: 800 }}>{fl.arrive}</div>
                    <div style={{ color: "var(--muted)", fontSize: 13 }}>{fl.to}</div>
                  </div>
                </div>
              </div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 28, fontWeight: 800, color: "var(--accent)" }}>{formatINR(fl.price)}</div>
              <div style={{ fontSize: 12, color: "var(--muted)" }}>per person</div>
              <div style={{ fontSize: 12, color: fl.seats < 15 ? "var(--red)" : "var(--green)", marginTop: 4 }}>
                {fl.seats} seats left
              </div>
              <button style={btn} onClick={(e) => { e.stopPropagation(); onBook(fl, "flights"); }}>
                Book Now
              </button>
            </div>
          </div>
        ))}

        {/* ── Hotels ── */}
        {type === "hotels" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
            {results.map((ht) => (
              <div
                key={ht.id}
                style={{ ...card, marginBottom: 0, cursor: "pointer" }}
                onClick={() => navigate(`/detail/hotels/${ht.id}`)}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = "var(--accent)")}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = "var(--border)")}
              >
                <div style={{ fontSize: 48, marginBottom: 16 }}>{ht.img}</div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <h3 style={{ margin: "0 0 4px", fontSize: 18 }}>{ht.name}</h3>
                    <div style={{ color: "var(--muted)", fontSize: 13 }}>📍 {ht.city}</div>
                  </div>
                  <div>{"⭐".repeat(ht.stars)}</div>
                </div>
                <p style={{ color: "var(--muted)", fontSize: 13, margin: "10px 0" }}>{ht.desc}</p>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <StarRating rating={ht.rating} />
                    <span style={{ fontSize: 12, color: "var(--muted)", marginLeft: 6 }}>({ht.reviews})</span>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 22, fontWeight: 800, color: "var(--accent)" }}>{formatINR(ht.price)}</div>
                    <div style={{ fontSize: 11, color: "var(--muted)" }}>per night</div>
                  </div>
                </div>
                <button style={{ ...btn, width: "100%", marginTop: 16, padding: "10px" }} onClick={(e) => { e.stopPropagation(); onBook(ht, "hotels"); }}>
                  Book Now
                </button>
              </div>
            ))}
          </div>
        )}

        {/* ── Packages ── */}
        {type === "packages" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16 }}>
            {results.map((pkg) => (
              <div
                key={pkg.id}
                style={{ ...card, marginBottom: 0, cursor: "pointer" }}
                onClick={() => navigate(`/detail/packages/${pkg.id}`)}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = "var(--accent)")}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = "var(--border)")}
              >
                <div style={{ fontSize: 48, marginBottom: 12 }}>{pkg.img}</div>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <h3 style={{ margin: 0, fontSize: 17, flex: 1 }}>{pkg.name}</h3>
                  <Badge color="var(--accent)">{pkg.days}D</Badge>
                </div>
                <p style={{ color: "var(--muted)", fontSize: 13, margin: "8px 0 12px" }}>{pkg.highlight}</p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 16 }}>
                  {pkg.includes.map((inc) => (
                    <span key={inc} style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 20, padding: "4px 12px", fontSize: 12, color: "var(--muted)" }}>{inc}</span>
                  ))}
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <StarRating rating={pkg.rating} />
                    <span style={{ fontSize: 12, color: "var(--muted)", marginLeft: 6 }}>({pkg.reviews})</span>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 22, fontWeight: 800, color: "var(--accent)" }}>{formatINR(pkg.price)}</div>
                    <div style={{ fontSize: 11, color: "var(--muted)" }}>per person</div>
                  </div>
                </div>
                <button style={{ ...btn, width: "100%", marginTop: 16, padding: "10px" }} onClick={(e) => { e.stopPropagation(); onBook(pkg, "packages"); }}>
                  Book Now
                </button>
              </div>
            ))}
          </div>
        )}

        {results.length === 0 && (
          <div style={{ textAlign: "center", padding: 60, color: "var(--muted)" }}>
            <div style={{ fontSize: 64, marginBottom: 16 }}>🔍</div>
            <h3>No results found</h3>
            <p>Try a different destination or date.</p>
          </div>
        )}
      </div>
    </div>
  );
}
