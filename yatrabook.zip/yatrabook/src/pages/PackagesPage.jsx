import React from "react";
import { useNavigate } from "react-router-dom";
import StarRating from "../components/StarRating";
import Badge from "../components/Badge";
import PACKAGES from "../data/packages";
import { formatINR } from "../utils/formatters";

export default function PackagesPage({ onBook }) {
  const navigate = useNavigate();

  const card = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: 16,
    padding: 24,
    cursor: "pointer",
    transition: "all 0.3s",
  };

  return (
    <div style={{ padding: "40px 20px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        {/* Page header */}
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <div style={{ fontSize: 12, color: "var(--accent)", letterSpacing: 3, textTransform: "uppercase", marginBottom: 8 }}>
            Handpicked Itineraries
          </div>
          <h1 style={{ fontSize: 40, fontWeight: 800, margin: "0 0 12px", letterSpacing: -1 }}>
            Vacation Packages
          </h1>
          <p style={{ color: "var(--muted)", fontSize: 16 }}>
            Complete travel experiences across incredible India
          </p>
        </div>

        {/* Grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 20 }}>
          {PACKAGES.map((pkg) => (
            <div
              key={pkg.id}
              style={card}
              onClick={() => navigate(`/detail/packages/${pkg.id}`)}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = "var(--accent)";
                e.currentTarget.style.transform = "translateY(-2px)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = "var(--border)";
                e.currentTarget.style.transform = "none";
              }}
            >
              <div style={{ fontSize: 52, marginBottom: 16 }}>{pkg.img}</div>

              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                <h3 style={{ margin: 0, fontSize: 18, fontWeight: 700, flex: 1 }}>{pkg.name}</h3>
                <Badge color="var(--accent)">{pkg.days}D/{pkg.nights}N</Badge>
              </div>

              <p style={{ color: "var(--muted)", fontSize: 13, margin: "0 0 14px", lineHeight: 1.6, fontStyle: "italic" }}>
                "{pkg.highlight}"
              </p>

              <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 16 }}>
                {pkg.includes.map((inc) => (
                  <span
                    key={inc}
                    style={{
                      background: "var(--surface)",
                      border: "1px solid var(--border)",
                      borderRadius: 20,
                      padding: "4px 12px",
                      fontSize: 12,
                      color: "var(--muted)",
                    }}
                  >
                    ✓ {inc}
                  </span>
                ))}
              </div>

              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <div>
                  <StarRating rating={pkg.rating} />
                  <span style={{ fontSize: 12, color: "var(--muted)", marginLeft: 6 }}>({pkg.reviews})</span>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 11, color: "var(--muted)" }}>from</div>
                  <div style={{ fontSize: 24, fontWeight: 800, color: "var(--accent)" }}>{formatINR(pkg.price)}</div>
                </div>
              </div>

              <button
                style={{
                  background: "linear-gradient(135deg, var(--accent), #FF8C5A)",
                  color: "#fff",
                  border: "none",
                  borderRadius: 10,
                  padding: "10px",
                  width: "100%",
                  fontWeight: 700,
                  fontSize: 14,
                  cursor: "pointer",
                  fontFamily: "var(--font)",
                }}
                onClick={(e) => { e.stopPropagation(); onBook(pkg, "packages"); }}
              >
                Book Now →
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
