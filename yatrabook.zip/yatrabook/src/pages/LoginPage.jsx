import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

/**
 * LoginPage – handles both login and registration.
 *
 * Props:
 *   onLogin    – fn(user) called on successful auth
 *   showToast  – fn(msg, type)
 */
export default function LoginPage({ onLogin, showToast }) {
  const navigate = useNavigate();
  const [isRegister, setIsRegister] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  const input = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    color: "var(--text)",
    borderRadius: 10,
    padding: "12px 16px",
    fontSize: 14,
    fontFamily: "var(--font)",
    outline: "none",
    width: "100%",
  };

  function handleSubmit() {
    if (!form.email || !form.password) {
      showToast("Please fill all fields", "error");
      return;
    }
    const user = {
      name: form.name || form.email.split("@")[0],
      email: form.email,
      isAdmin: form.email.toLowerCase().includes("admin"),
    };
    onLogin(user);
    showToast(`Welcome, ${user.name}! 🙏`);
    navigate("/");
  }

  return (
    <div style={{ padding: "60px 20px", display: "flex", justifyContent: "center" }}>
      <div style={{ width: "100%", maxWidth: 420 }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 48, marginBottom: 8 }}>🙏</div>
          <h2 style={{ fontSize: 32, fontWeight: 800, margin: "0 0 8px" }}>
            {isRegister ? "Join YatraBook" : "Welcome Back"}
          </h2>
          <p style={{ color: "var(--muted)" }}>Your journey begins here</p>
        </div>

        {/* Form card */}
        <div
          style={{
            background: "var(--card)",
            border: "1px solid var(--border)",
            borderRadius: 16,
            padding: 28,
            display: "flex",
            flexDirection: "column",
            gap: 16,
          }}
        >
          {isRegister && (
            <div>
              <label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>FULL NAME</label>
              <input
                style={input}
                placeholder="Rahul Sharma"
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              />
            </div>
          )}

          <div>
            <label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>EMAIL</label>
            <input
              style={input}
              type="email"
              placeholder="rahul@example.com"
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            />
          </div>

          <div>
            <label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>PASSWORD</label>
            <input
              style={input}
              type="password"
              placeholder="••••••••"
              value={form.password}
              onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
            />
          </div>

          <button
            onClick={handleSubmit}
            style={{
              background: "linear-gradient(135deg, var(--accent), #FF8C5A)",
              color: "#fff",
              border: "none",
              borderRadius: 10,
              padding: "14px",
              fontWeight: 700,
              fontSize: 15,
              cursor: "pointer",
              fontFamily: "var(--font)",
              width: "100%",
            }}
          >
            {isRegister ? "Create Account" : "Login"} →
          </button>

          <div style={{ textAlign: "center", fontSize: 13, color: "var(--muted)" }}>
            {isRegister ? "Already have an account? " : "Don't have an account? "}
            <button
              style={{ background: "none", border: "none", color: "var(--accent)", cursor: "pointer", fontFamily: "var(--font)", fontSize: 13, fontWeight: 700 }}
              onClick={() => setIsRegister(!isRegister)}
            >
              {isRegister ? "Login" : "Register"}
            </button>
          </div>

          <div style={{ borderTop: "1px solid var(--border)", paddingTop: 16, textAlign: "center", fontSize: 12, color: "var(--muted)" }}>
            💡 Tip: use an email with "admin" to access the Admin Panel
          </div>
        </div>
      </div>
    </div>
  );
}
