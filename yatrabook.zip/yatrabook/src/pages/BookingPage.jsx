import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { formatINR } from "../utils/formatters";

/**
 * BookingPage – shows booking details form, then payment, then confirmation.
 *
 * Props:
 *   cart           – { item, type, date }
 *   user           – current user
 *   onConfirm      – fn(item, type, date) — called after successful payment
 */
export default function BookingPage({ cart, user, onConfirm }) {
  const navigate = useNavigate();
  const [step, setStep]         = useState("details"); // "details" | "payment" | "done"
  const [payMethod, setPayMethod] = useState("card");
  const [confirmedBooking, setConfirmedBooking] = useState(null);

  if (!cart) {
    return (
      <div style={{ padding: 60, textAlign: "center", color: "var(--muted)" }}>
        <div style={{ fontSize: 64 }}>🛒</div>
        <h3>No booking in progress</h3>
        <button onClick={() => navigate("/")} style={{ color: "var(--accent)", background: "none", border: "none", cursor: "pointer", fontSize: 16 }}>
          ← Back to Home
        </button>
      </div>
    );
  }

  const { item, type, date } = cart;
  const gst = Math.round(item.price * 0.05);
  const total = item.price + gst;

  const card = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: 16,
    padding: 24,
    marginBottom: 20,
  };

  const input = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    color: "var(--text)",
    borderRadius: 10,
    padding: "12px 16px",
    fontSize: 14,
    fontFamily: "var(--font)",
    outline: "none",
    width: "100%",
  };

  const btn = {
    background: "linear-gradient(135deg, var(--accent), #FF8C5A)",
    color: "#fff",
    border: "none",
    borderRadius: 10,
    padding: "14px",
    width: "100%",
    fontWeight: 700,
    fontSize: 16,
    cursor: "pointer",
    fontFamily: "var(--font)",
    marginTop: 8,
  };

  function handlePayment() {
    const bk = onConfirm(item, type, date);
    setConfirmedBooking(bk);
    setStep("done");
  }

  // ── Step: Confirmed ────────────────────────────────────────────────────────
  if (step === "done") {
    return (
      <div style={{ padding: "60px 20px", textAlign: "center" }}>
        <div style={{ maxWidth: 500, margin: "0 auto" }}>
          <div style={{ fontSize: 80, marginBottom: 24 }}>🎉</div>
          <h2 style={{ fontSize: 32, fontWeight: 800, color: "var(--green)", marginBottom: 12 }}>
            Booking Confirmed!
          </h2>
          <p style={{ color: "var(--muted)", marginBottom: 24 }}>
            Your journey to {item.to || item.city || item.dest} is confirmed. Check your email for details.
          </p>
          <div style={{ ...card, textAlign: "left" }}>
            <div style={{ fontWeight: 700, marginBottom: 12 }}>Booking Summary</div>
            <div style={{ color: "var(--muted)", fontSize: 14, lineHeight: 2 }}>
              <div>📌 <strong style={{ color: "var(--text)" }}>{item.name || `${item.airline}: ${item.from} → ${item.to}`}</strong></div>
              <div>🪪 Booking ID: <strong style={{ color: "var(--text)" }}>{confirmedBooking?.id}</strong></div>
              <div>📅 Travel Date: <strong style={{ color: "var(--text)" }}>{date || "TBD"}</strong></div>
              <div>💰 Amount Paid: <strong style={{ color: "var(--accent)" }}>{formatINR(total)}</strong></div>
              <div>✅ Status: <strong style={{ color: "var(--green)" }}>Confirmed</strong></div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
            <button style={{ ...btn, width: "auto", padding: "12px 28px" }} onClick={() => navigate("/dashboard")}>
              View My Bookings
            </button>
            <button
              style={{ ...btn, width: "auto", padding: "12px 28px", background: "transparent", color: "var(--accent)", border: "1.5px solid var(--accent)" }}
              onClick={() => navigate("/")}
            >
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── Step: Payment ──────────────────────────────────────────────────────────
  if (step === "payment") {
    return (
      <div style={{ padding: "40px 20px" }}>
        <div style={{ maxWidth: 560, margin: "0 auto" }}>
          <button onClick={() => setStep("details")} style={{ background: "none", border: "1px solid var(--border)", color: "var(--muted)", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontFamily: "var(--font)", marginBottom: 20 }}>
            ← Back
          </button>
          <h2 style={{ fontSize: 28, fontWeight: 800, marginBottom: 24 }}>💳 Secure Payment</h2>

          {/* Order summary */}
          <div style={card}>
            <div style={{ fontWeight: 700, marginBottom: 12, color: "var(--muted)", fontSize: 12, letterSpacing: 1, textTransform: "uppercase" }}>Order Summary</div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <span>{item.name || `${item.from} → ${item.to}`}</span>
              <span style={{ fontWeight: 700, color: "var(--accent)" }}>{formatINR(item.price)}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", color: "var(--muted)", fontSize: 13 }}>
              <span>GST (5%)</span><span>{formatINR(gst)}</span>
            </div>
            <div style={{ borderTop: "1px solid var(--border)", marginTop: 12, paddingTop: 12, display: "flex", justifyContent: "space-between", fontWeight: 800, fontSize: 18 }}>
              <span>Total</span>
              <span style={{ color: "var(--accent)" }}>{formatINR(total)}</span>
            </div>
          </div>

          {/* Payment method tabs */}
          <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
            {[["card", "💳 Card"], ["upi", "📱 UPI"], ["netbanking", "🏦 Net Banking"]].map(([m, l]) => (
              <button
                key={m}
                onClick={() => setPayMethod(m)}
                style={{
                  flex: 1,
                  background: payMethod === m ? "var(--accent)22" : "var(--card)",
                  border: `1.5px solid ${payMethod === m ? "var(--accent)" : "var(--border)"}`,
                  color: payMethod === m ? "var(--accent)" : "var(--muted)",
                  borderRadius: 10,
                  padding: "10px 8px",
                  fontSize: 13,
                  cursor: "pointer",
                  fontFamily: "var(--font)",
                }}
              >
                {l}
              </button>
            ))}
          </div>

          {/* Card form */}
          {payMethod === "card" && (
            <div style={{ ...card, display: "flex", flexDirection: "column", gap: 14 }}>
              <div><label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>CARD NUMBER</label><input style={input} placeholder="4242 4242 4242 4242" maxLength={19} /></div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div><label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>EXPIRY</label><input style={input} placeholder="MM/YY" /></div>
                <div><label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>CVV</label><input style={input} placeholder="•••" type="password" maxLength={3} /></div>
              </div>
              <div><label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>NAME ON CARD</label><input style={input} placeholder="Your Name" /></div>
            </div>
          )}

          {/* UPI form */}
          {payMethod === "upi" && (
            <div style={card}>
              <label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>UPI ID</label>
              <input style={input} placeholder="yourname@upi" />
              <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 12 }}>Supports: GPay, PhonePe, Paytm, BHIM UPI</div>
            </div>
          )}

          {/* Net banking */}
          {payMethod === "netbanking" && (
            <div style={card}>
              <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 12 }}>SELECT BANK</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                {["SBI", "HDFC", "ICICI", "Axis", "PNB", "Kotak"].map((b) => (
                  <button key={b} style={{ background: "var(--surface)", border: "1px solid var(--border)", color: "var(--text)", borderRadius: 8, padding: 10, cursor: "pointer", fontFamily: "var(--font)" }}>{b}</button>
                ))}
              </div>
            </div>
          )}

          <button style={btn} onClick={handlePayment}>
            Pay {formatINR(total)} Securely 🔒
          </button>
          <div style={{ textAlign: "center", fontSize: 12, color: "var(--muted)", marginTop: 12 }}>
            Protected by 256-bit SSL encryption
          </div>
        </div>
      </div>
    );
  }

  // ── Step: Details ──────────────────────────────────────────────────────────
  return (
    <div style={{ padding: "40px 20px" }}>
      <div style={{ maxWidth: 700, margin: "0 auto" }}>
        <button onClick={() => navigate(-1)} style={{ background: "none", border: "1px solid var(--border)", color: "var(--muted)", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontFamily: "var(--font)", marginBottom: 20 }}>
          ← Back
        </button>

        <h2 style={{ fontSize: 28, fontWeight: 800, marginBottom: 24 }}>🗓 Booking Details</h2>

        {/* Selection summary */}
        <div style={card}>
          <div style={{ fontWeight: 700, marginBottom: 16, color: "var(--muted)", fontSize: 12, letterSpacing: 1, textTransform: "uppercase" }}>Your Selection</div>
          <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
            <div>
              <h3 style={{ margin: "0 0 8px", fontSize: 20 }}>
                {item.name || `${item.airline} — ${item.from} → ${item.to}`}
              </h3>
              <div style={{ color: "var(--muted)", fontSize: 14, lineHeight: 2 }}>
                {item.city  && <div>📍 {item.city}</div>}
                {item.dest  && <div>📍 {item.dest} • {item.days}D/{item.nights}N</div>}
                {item.depart && <div>⏰ {item.depart} → {item.arrive} ({item.duration})</div>}
                <div>📅 Travel Date: {date || "Not selected"}</div>
              </div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 32, fontWeight: 800, color: "var(--accent)" }}>{formatINR(item.price)}</div>
              <div style={{ fontSize: 13, color: "var(--muted)" }}>+ {formatINR(gst)} GST</div>
            </div>
          </div>
        </div>

        {/* Traveller details */}
        <div style={{ ...card, display: "flex", flexDirection: "column", gap: 14 }}>
          <div style={{ fontWeight: 700, fontSize: 15 }}>Traveller Details</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div><label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>FIRST NAME</label><input style={input} defaultValue={user?.name?.split(" ")[0]} /></div>
            <div><label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>LAST NAME</label><input style={input} /></div>
          </div>
          <div><label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>EMAIL</label><input style={input} defaultValue={user?.email} /></div>
          <div><label style={{ fontSize: 12, color: "var(--muted)", display: "block", marginBottom: 6 }}>PHONE NUMBER</label><input style={input} placeholder="+91 XXXXX XXXXX" /></div>
        </div>

        {/* Travel insurance */}
        <div style={{ ...card, display: "flex", gap: 12, alignItems: "center" }}>
          <span style={{ fontSize: 24 }}>🛡️</span>
          <div>
            <div style={{ fontWeight: 700 }}>Travel Insurance — {formatINR(299)}</div>
            <div style={{ fontSize: 13, color: "var(--muted)" }}>Cover trip cancellations, medical emergencies & baggage loss</div>
          </div>
          <input type="checkbox" style={{ marginLeft: "auto", width: 20, height: 20, accentColor: "var(--accent)" }} />
        </div>

        <button style={btn} onClick={() => setStep("payment")}>
          Proceed to Payment →
        </button>
      </div>
    </div>
  );
}
