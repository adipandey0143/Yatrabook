import React, { useState } from "react";
import Badge from "../components/Badge";
import StarRating from "../components/StarRating";
import FLIGHTS from "../data/flights";
import HOTELS from "../data/hotels";
import PACKAGES from "../data/packages";
import { formatINR } from "../utils/formatters";

/**
 * AdminPage – administrator control panel.
 *
 * Props:
 *   bookings    – all bookings array
 *   reviews     – all reviews array
 *   onDeleteReview – fn(id)
 *   showToast   – fn(msg, type)
 */
export default function AdminPage({ bookings, reviews, onDeleteReview, showToast }) {
  const [tab, setTab] = useState("dashboard");

  const totalRevenue = bookings
    .filter((b) => b.status === "Confirmed")
    .reduce((s, b) => s + b.amount, 0);

  const card = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
  };

  const TABS = ["dashboard", "listings", "customers", "reviews"];

  return (
    <div style={{ padding: "32px 20px" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        {/* Header */}
        <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 28 }}>
          <span style={{ fontSize: 32 }}>⚙️</span>
          <h2 style={{ margin: 0, fontSize: 28, fontWeight: 800 }}>Admin Panel</h2>
          <Badge color="var(--accent2)">Admin Access</Badge>
        </div>

        {/* Stats grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 16, marginBottom: 28 }}>
          {[
            { label: "Total Flights",  value: FLIGHTS.length,   icon: "✈",  color: "var(--accent)"  },
            { label: "Hotels Listed",  value: HOTELS.length,    icon: "🏨", color: "var(--accent3)" },
            { label: "Packages",       value: PACKAGES.length,  icon: "🗺", color: "var(--accent2)" },
            { label: "Revenue (Demo)", value: formatINR(totalRevenue + 250000), icon: "💰", color: "var(--green)" },
          ].map((s) => (
            <div key={s.label} style={{ ...card, textAlign: "center", marginBottom: 0 }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>{s.icon}</div>
              <div style={{ fontSize: s.icon === "💰" ? 18 : 26, fontWeight: 800, color: s.color }}>{s.value}</div>
              <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 4 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 8, marginBottom: 24, borderBottom: "1px solid var(--border)", paddingBottom: 12 }}>
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              style={{
                background: "none",
                border: "none",
                color: tab === t ? "var(--accent)" : "var(--muted)",
                cursor: "pointer",
                padding: "8px 16px",
                borderBottom: tab === t ? "2px solid var(--accent)" : "2px solid transparent",
                fontFamily: "var(--font)",
                fontWeight: tab === t ? 700 : 400,
                fontSize: 14,
                textTransform: "capitalize",
              }}
            >
              {t}
            </button>
          ))}
        </div>

        {/* ── Dashboard tab ── */}
        {tab === "dashboard" && (
          <div>
            <h3 style={{ marginBottom: 16 }}>Recent Bookings</h3>
            {bookings.length === 0 ? (
              <div style={{ ...card, textAlign: "center", color: "var(--muted)", padding: 40 }}>
                No bookings yet in demo mode. Make a booking to see it here.
              </div>
            ) : (
              bookings.map((bk) => (
                <div key={bk.id} style={{ ...card, display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
                  <div>
                    <div style={{ fontWeight: 700 }}>
                      {bk.item.name || `${bk.item.airline}: ${bk.item.from} → ${bk.item.to}`}
                    </div>
                    <div style={{ color: "var(--muted)", fontSize: 13 }}>
                      #{bk.id} &nbsp;•&nbsp; {bk.date} &nbsp;•&nbsp; Booked {bk.bookedOn}
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                    <span style={{ fontWeight: 700, color: "var(--accent)" }}>{formatINR(bk.amount)}</span>
                    <Badge color={bk.status === "Confirmed" ? "var(--green)" : "var(--red)"}>{bk.status}</Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* ── Listings tab ── */}
        {tab === "listings" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
              <h3 style={{ margin: 0 }}>Manage Listings</h3>
              <button
                onClick={() => showToast("Add listing form would open here")}
                style={{ background: "linear-gradient(135deg, var(--accent), #FF8C5A)", color: "#fff", border: "none", borderRadius: 10, padding: "8px 18px", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "var(--font)" }}
              >
                + Add New
              </button>
            </div>

            {[...FLIGHTS, ...HOTELS, ...PACKAGES].map((item) => (
              <div key={item.id} style={{ ...card, padding: "14px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10 }}>
                <div>
                  <span style={{ fontWeight: 700 }}>
                    {item.name || `${item.airline}: ${item.from} → ${item.to}`}
                  </span>
                  <span style={{ color: "var(--muted)", fontSize: 12, marginLeft: 10 }}>{item.id}</span>
                </div>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <span style={{ color: "var(--accent)", fontWeight: 700 }}>{formatINR(item.price)}</span>
                  <button
                    onClick={() => showToast("Edit form opened")}
                    style={{ background: "transparent", color: "var(--accent)", border: "1.5px solid var(--accent)", borderRadius: 8, padding: "4px 12px", fontSize: 12, cursor: "pointer", fontFamily: "var(--font)" }}
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => showToast("Item removed (demo only)", "error")}
                    style={{ background: "var(--red)22", color: "var(--red)", border: "1px solid var(--red)44", borderRadius: 8, padding: "4px 12px", fontSize: 12, cursor: "pointer", fontFamily: "var(--font)" }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── Reviews tab ── */}
        {tab === "reviews" && (
          <div>
            <h3 style={{ marginBottom: 16 }}>Review Moderation ({reviews.length})</h3>
            {reviews.map((rv) => (
              <div key={rv.id} style={{ ...card, display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", gap: 10, marginBottom: 6, flexWrap: "wrap" }}>
                    <span style={{ fontWeight: 700 }}>{rv.user}</span>
                    <StarRating rating={rv.rating} size={12} />
                    <span style={{ fontSize: 12, color: "var(--muted)" }}>{rv.date}</span>
                    <Badge color="var(--muted)">{rv.itemId}</Badge>
                  </div>
                  <p style={{ color: "var(--muted)", fontSize: 14, margin: 0 }}>"{rv.text}"</p>
                </div>
                <button
                  onClick={() => { onDeleteReview(rv.id); showToast("Review removed"); }}
                  style={{ background: "var(--red)22", color: "var(--red)", border: "1px solid var(--red)44", borderRadius: 8, padding: "6px 14px", fontSize: 12, cursor: "pointer", fontFamily: "var(--font)", whiteSpace: "nowrap" }}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        )}

        {/* ── Customers tab ── */}
        {tab === "customers" && (
          <div style={{ ...card, textAlign: "center", color: "var(--muted)", padding: 60 }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>👥</div>
            <p>Customer data will appear here when users register in a live deployment with a real database.</p>
          </div>
        )}
      </div>
    </div>
  );
}
