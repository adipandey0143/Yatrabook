import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import SearchBox from "../components/SearchBox";
import StarRating from "../components/StarRating";
import PACKAGES from "../data/packages";
import REVIEWS from "../data/reviews";
import { FEATURED_DESTINATIONS } from "../data/destinations";
import { formatINR } from "../utils/formatters";

const HERO_SLIDES = [
  "🕯️ Varanasi Ghats",
  "🌴 Kerala Backwaters",
  "❄️ Kashmir Valleys",
  "🕌 Lucknow Heritage",
  "🌸 Bangalore Gardens",
  "🎨 Azamgarh Culture",
];

export default function HomePage() {
  const navigate = useNavigate();
  const [heroIdx, setHeroIdx] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setHeroIdx((i) => (i + 1) % HERO_SLIDES.length), 2500);
    return () => clearInterval(t);
  }, []);

  const card = {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: 16,
    padding: 24,
  };

  return (
    <div>
      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <div
        style={{
          background:
            "linear-gradient(160deg, #0A0A0F 0%, #1A0A00 50%, #0A0A0F 100%)",
          padding: "80px 20px 60px",
          textAlign: "center",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage:
              "radial-gradient(circle at 20% 50%, rgba(255,107,53,0.08) 0%, transparent 60%), radial-gradient(circle at 80% 20%, rgba(255,215,0,0.06) 0%, transparent 50%)",
            pointerEvents: "none",
          }}
        />
        <div style={{ maxWidth: 780, margin: "0 auto", position: "relative" }}>
          <div
            style={{
              fontSize: 13,
              color: "var(--accent)",
              letterSpacing: 3,
              textTransform: "uppercase",
              marginBottom: 16,
              fontFamily: "monospace",
            }}
          >
            🇮🇳 Incredible India Travel Platform
          </div>

          <h1
            style={{
              fontSize: "clamp(36px, 6vw, 72px)",
              fontWeight: 900,
              lineHeight: 1.1,
              margin: "0 0 16px",
              letterSpacing: -2,
            }}
          >
            Discover the{" "}
            <span style={{ color: "var(--accent)" }}>Soul</span> of{" "}
            <span
              style={{
                background:
                  "linear-gradient(135deg, var(--accent2), var(--accent))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              India
            </span>
          </h1>

          <div style={{ fontSize: 28, marginBottom: 8, minHeight: 40 }}>
            {HERO_SLIDES[heroIdx]}
          </div>

          <p
            style={{
              color: "var(--muted)",
              fontSize: 17,
              marginBottom: 48,
              lineHeight: 1.6,
            }}
          >
            From the sacred ghats of Varanasi to the pristine valleys of
            Kashmir — every journey tells a story.
          </p>

          <SearchBox />
        </div>
      </div>

      {/* ── Stats Bar ─────────────────────────────────────────────────────── */}
      <div
        style={{
          background: "var(--surface)",
          borderBottom: "1px solid var(--border)",
          padding: "20px 0",
        }}
      >
        <div
          style={{
            maxWidth: 1100,
            margin: "0 auto",
            padding: "0 20px",
            display: "flex",
            justifyContent: "space-around",
            flexWrap: "wrap",
            gap: 16,
          }}
        >
          {[
            ["50,000+", "Happy Travellers"],
            ["200+", "Destinations"],
            ["98%", "Satisfaction Rate"],
            ["₹ Best", "Price Guarantee"],
          ].map(([n, l]) => (
            <div key={l} style={{ textAlign: "center" }}>
              <div style={{ fontSize: 24, fontWeight: 800, color: "var(--accent)" }}>{n}</div>
              <div style={{ fontSize: 12, color: "var(--muted)", letterSpacing: 0.5 }}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Featured Packages ─────────────────────────────────────────────── */}
      <div style={{ padding: "60px 20px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ marginBottom: 32 }}>
            <div
              style={{
                fontSize: 12,
                color: "var(--accent)",
                letterSpacing: 3,
                textTransform: "uppercase",
                marginBottom: 8,
              }}
            >
              Curated Experiences
            </div>
            <h2 style={{ fontSize: 36, fontWeight: 800, margin: 0, letterSpacing: -1 }}>
              Trending Packages
            </h2>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
              gap: 20,
            }}
          >
            {PACKAGES.slice(0, 3).map((pkg) => (
              <div
                key={pkg.id}
                style={{ ...card, cursor: "pointer", transition: "border 0.2s" }}
                onClick={() => navigate(`/detail/packages/${pkg.id}`)}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = "var(--accent)")}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = "var(--border)")}
              >
                <div style={{ fontSize: 48, marginBottom: 16 }}>{pkg.img}</div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "flex-start",
                    marginBottom: 8,
                  }}
                >
                  <h3 style={{ margin: 0, fontSize: 18, fontWeight: 700, lineHeight: 1.3 }}>
                    {pkg.name}
                  </h3>
                  <span
                    style={{
                      background: "var(--accent)22",
                      color: "var(--accent)",
                      borderRadius: 20,
                      padding: "2px 10px",
                      fontSize: 11,
                      fontWeight: 700,
                    }}
                  >
                    {pkg.days}D/{pkg.nights}N
                  </span>
                </div>
                <p
                  style={{
                    color: "var(--muted)",
                    fontSize: 13,
                    margin: "8px 0 16px",
                    lineHeight: 1.5,
                  }}
                >
                  {pkg.highlight}
                </p>
                <div
                  style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
                >
                  <div>
                    <StarRating rating={pkg.rating} />
                    <span style={{ fontSize: 12, color: "var(--muted)", marginLeft: 6 }}>
                      ({pkg.reviews})
                    </span>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 11, color: "var(--muted)" }}>from</div>
                    <div style={{ fontSize: 22, fontWeight: 800, color: "var(--accent)" }}>
                      {formatINR(pkg.price)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ textAlign: "center", marginTop: 32 }}>
            <button
              style={{
                background: "transparent",
                color: "var(--accent)",
                border: "1.5px solid var(--accent)",
                borderRadius: 10,
                padding: "10px 28px",
                fontWeight: 600,
                fontSize: 14,
                cursor: "pointer",
                fontFamily: "var(--font)",
              }}
              onClick={() => navigate("/packages")}
            >
              View All Packages →
            </button>
          </div>
        </div>
      </div>

      {/* ── Destinations Grid ─────────────────────────────────────────────── */}
      <div style={{ background: "var(--surface)", padding: "60px 20px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <h2 style={{ fontSize: 36, fontWeight: 800, marginBottom: 32, letterSpacing: -1 }}>
            Popular Destinations
          </h2>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))",
              gap: 12,
            }}
          >
            {FEATURED_DESTINATIONS.map((dest) => (
              <div
                key={dest.name}
                style={{ ...card, textAlign: "center", padding: 20, cursor: "pointer", transition: "all 0.2s" }}
                onClick={() => navigate("/search", { state: { type: "hotels", to: dest.name } })}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "#22223A";
                  e.currentTarget.style.borderColor = "var(--accent)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "var(--card)";
                  e.currentTarget.style.borderColor = "var(--border)";
                }}
              >
                <div style={{ fontSize: 36, marginBottom: 8 }}>{dest.icon}</div>
                <div style={{ fontWeight: 700, fontSize: 14 }}>{dest.name}</div>
                <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 4 }}>{dest.tag}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Traveller Reviews ─────────────────────────────────────────────── */}
      <div style={{ padding: "60px 20px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <h2 style={{ fontSize: 36, fontWeight: 800, marginBottom: 32, letterSpacing: -1 }}>
            Traveller Stories
          </h2>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
              gap: 16,
            }}
          >
            {REVIEWS.map((rv) => (
              <div key={rv.id} style={card}>
                <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
                  <span style={{ fontSize: 32 }}>{rv.avatar}</span>
                  <div>
                    <div style={{ fontWeight: 700 }}>{rv.user}</div>
                    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                      <StarRating rating={rv.rating} size={12} />
                      <span style={{ fontSize: 11, color: "var(--muted)" }}>{rv.date}</span>
                    </div>
                  </div>
                </div>
                <p
                  style={{
                    color: "var(--muted)",
                    fontSize: 14,
                    lineHeight: 1.6,
                    margin: 0,
                    fontStyle: "italic",
                  }}
                >
                  "{rv.text}"
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
